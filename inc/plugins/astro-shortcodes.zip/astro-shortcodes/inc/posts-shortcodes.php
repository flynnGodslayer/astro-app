<?php
/**
 * Module Shortcodes
 *
 * @package Astro Shortcodes
 */

/**
 * "RECENT-ITEMS" Shortcode
 */
add_shortcode('recent-items', 'astro_shortcodes_recent_items');
function astro_shortcodes_recent_items( $atts ) {
    $args = shortcode_atts(array(
        'type' => 'post',
        'category' => '',
        'number' => 3,
        'content' => ''
    ), $atts, 'recent-items' );

    $singleID = '';
    if ( is_single() ) {
        $singleID = get_the_ID();
    }

    $class = '';
    if ( $args['number'] == 1 ) { 
        $class = " offset_3 col span_6_of_12"; 
    } elseif ( $args['number'] == 2 ) { 
        $class = " col span_6_of_12"; 
    } else {
        $class = " col span_4_of_12";
    }

    ob_start();

    $recent_args = array(
        'post_type' => $args['type'],
        'category_name'     => $args['category'],
        'posts_per_page' => $args['number'] + 1,
    );
    

    $recent_loop = new WP_Query($recent_args); 
    if( $recent_loop->have_posts() ): 
        $count = 1;
    ?>
        <div class="astro-shortcodes recent-items section group">
    <?php
        while( $recent_loop->have_posts() ): $recent_loop->the_post(); 

            $id = get_the_ID();

            if ( $id != $singleID && $count <= $args['number'] ) :
    ?>
            <div class="<?php echo esc_attr( $class ); ?>">
                <article id="<?php echo $args['type'] . '-' . $id; ?>" class="<?php echo $args['type']; ?>"><a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark" class="thumbnail-link"><?php 
                    if ( has_post_thumbnail() ){ the_post_thumbnail( 'large' ); } 
                ?><div class="overlay"><?php
                    the_title( '<h3 class="entry-title">', '</h3>' );
                    if ( $args['content'] == 'excerpt' ) {
                        the_excerpt();
                    }
                ?></div></a></article>
            </div>
    <?php   
                $count++;
            endif;
        endwhile; 
    ?>
        </div>
    <?php else : ?>
        <span><?php _e( 'No entries were found.', 'astro-shortcodes' ); ?></span>
    <?php
    endif;
    $module = ob_get_contents();
    ob_end_clean();
    wp_reset_postdata();
    return $module;
}

/**
 * "PAGE-BUTTON" Shortcode
 */
add_shortcode( 'page-button', 'astro_shortcodes_page_button' );
function astro_shortcodes_page_button( $atts ) {
    $args = shortcode_atts(array(
        'name'      => '',
        'class'     => 'narrow short',
        'color'     => '#000000',
    ), $atts, 'page-button' );

    if ( $args['name'] == '' ) {
        return;
    }

    $page = get_page_by_title( $args['name'] );

    if ( ! $page ) {
        return;
    }

    $page_id = $page->ID;
    $page_slug = $page->post_name;
    $page_link = get_page_link( $page_id );
    $page_title = apply_filters( 'the_title', $page->post_title );   
    $featured_img_url = get_the_post_thumbnail_url( $page->ID, 'large' ); 

    $link = 'href="' . esc_url( $page_link ). '"';
    $class = ' class="' . esc_attr( $page_slug ) . ' ' . $args['class'] . '"';
    $style = ' style="background-color: ' . $args['color'] . ';';


    if ( ! empty( $featured_img_url ) ) {
        $style .= 'background-image: url(' . esc_url( $featured_img_url ) . ');';
    }

    $style .= '"';

    ob_start();
    ?><div class="astro-shortcodes page-button"><a <?php echo $link . $class . $style; ?>></a><h3><a <?php echo $link; ?>><?php echo esc_html( $page_title ); ?></a></h3></div><?php
    $button = ob_get_contents();
    ob_end_clean();
    return $button;
}

/**
 * "PROJECT-LIST" Shortcode
 */
add_shortcode('project-list', 'astro_shortcodes_project_list');
function astro_shortcodes_project_list() {
    
    ob_start();

    $projects_args = array(
        'post_type' => 'jetpack-portfolio',
        'posts_per_page' => -1,
    );
    

    $projects_loop = new WP_Query($projects_args); 
    if( $projects_loop->have_posts() ): 
        $count = 1;
    ?>
        <div class="astro-shortcodes project-list section group">
    <?php
        while( $projects_loop->have_posts() ): $projects_loop->the_post(); 

            $id = get_the_ID();
            $types = get_the_terms( $id, 'jetpack-portfolio-type' );
            $class = '';
            $type = '';
            if ( $types ) {
                $type = $types[0]->slug;
            }
            
            if ( $count <= 2 ) { 
                $class = " col span_6_of_12 " . $type; 
            } else {
                $class = " col span_4_of_12 " . $type;
            }
    ?>

            <article id="project-<?php echo $id; ?>" class="project<?php echo esc_attr( $class ); ?>"><a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark" class="thumbnail-link"><?php 
                    if ( has_post_thumbnail() ){ the_post_thumbnail( 'large' ); } 
            ?><div class="overlay"><?php 
                the_title( '<h3 class="project-title">', '</h3>' ); 
            ?><span><?php echo esc_html( get_post_meta( $id, 'project_description', true ) ); ?></span></div></a></article>
    <?php   
            if ( $count < 5 ) {
                $count++;
            } else {
                $count = 1;
            }
        endwhile; 
    ?>
        </div>
    <?php else : ?>
        <span><?php _e( 'No projects were found.', 'astro-shortcodes' ); ?></span>
    <?php
    endif;
    $module = ob_get_contents();
    ob_end_clean();
    wp_reset_postdata();
    return $module;
}


/**
 * "ASTRO-CHILDREN"
 */
add_shortcode( 'astro-children', 'astro_shortcodes_children' );
function astro_shortcodes_children() {

    ob_start();

    $pages_query = new WP_Query();
    $all_wp_pages = $pages_query->query( array( 'post_type' => 'page', 'order' => 'ASC', 'orderby' => 'menu_order' ));
    $page_children = get_page_children( get_the_ID(), $all_wp_pages );
    if ( ! empty( $page_children ) ) :
    ?>
    <section class="astro-shortcodes children-list section group"><?php 
        foreach ( $page_children as $page ) :
            $raw_title = $page->post_title; 
            $split_title = explode( ' / ', $raw_title );
            $title = '<span>' . esc_html( $split_title[0] ) . ' / </span>' . esc_html( $split_title[1] ); 
    ?><div class="child-item col span_6_of_12"><?php 
            if ( has_post_thumbnail( $page->ID ) ) : 
            ?><a href="<?php echo esc_url( get_permalink( $page->ID ) ); ?>" title="<?php echo esc_attr( $page->post_title ); ?>"><?php 
                    echo get_the_post_thumbnail( $page->ID, 'medium' ); 
                ?></a><?php 
                    endif; 
                ?><h2 class="child-title"><a href="<?php echo esc_url( get_permalink( $page->ID ) ); ?>" title="<?php echo esc_attr( $page->post_title ); ?>"><?php 
                    echo $title; ?></a></h2></div><?php 
        endforeach; 
    ?></section><?php 
    endif;

    $module = ob_get_contents();
    ob_end_clean();
    wp_reset_postdata();
    return $module;
}