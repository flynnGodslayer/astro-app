<?php
/**
 * Taxonomy Shortcodes
 *
 * @package Astro Shortcodes
 */

/**
 * "TAXONOMY-BUTTON" Shortcode
 */
add_shortcode( 'taxonomy-button', 'astro_shortcodes_taxonomy_button' );
function astro_shortcodes_taxonomy_button( $atts ) {
    $args = shortcode_atts(array(
        'tax'       => 'category',
        'term'      => '',
        'class'     => 'narrow short',
        'color'     => '#000000',
    ), $atts, 'taxonomy-button' );

    $tax = get_term_by( 'name', $args['term'], $args['tax'] );

    if ( ! $tax ) {
        return;
    }

    $tax_id = $tax->term_id;
    $tax_slug = $tax->slug;
    $tax_name = $tax->name;
    $term_link = get_term_link( $tax_id );

    $link = 'href="' . esc_url( $term_link ). '"';
    $class = ' class="' . esc_attr( $tax_slug ) . ' ' . $args['class'] . '"';
    $style = ' style="background-color: ' . $args['color'] . ';';

    $image_id = get_term_meta( $tax_id, 'image', true );
    $image_data = wp_get_attachment_image_src( $image_id, 'medium' );
    $image = $image_data[0];


    if ( ! empty( $image ) ) {
        $style .= 'background-image: url(' . esc_url( $image ) . ');';
    }

    $style .= '"';

    ob_start();
    ?><div class="astro-shortcodes taxonomy-button"><a <?php echo $link . $class . $style; ?>></a><h3><a <?php echo $link; ?>><?php echo esc_html( $tax_name ); ?></a></h3></div><?php
    $button = ob_get_contents();
    ob_end_clean();
    return $button;
}

/**
 * "TAXONOMY-LIST" Shortcode
 */
add_shortcode( 'taxonomy-list', 'astro_shortcodes_get_taxonomies' );
function astro_shortcodes_get_taxonomies( $atts ) {
    $args = shortcode_atts(array(
        'tax' => 'category',
        'class'    => 'simple'
    ), $atts, 'taxonomy-list' );

    if ( $args['class'] == 'filters' ) {
        $empty = 1;
    } else {
        $empty = 0;
    }

    $taxs = get_terms( array(
                'taxonomy'   => $args['tax'],
                'orderby'    => 'id',
                'hide_empty' => $empty
            ) );
    
    ob_start();

    if ( ! empty( $taxs ) && ! is_wp_error( $taxs ) ) {

        if ( $args['class'] == 'simple') {
            echo '<ul class="astro-shortcodes taxonomy-list">';
            foreach ( $taxs as $tax ) {
                echo '<li class="' . $tax->slug . '"><a href="' . esc_url( get_term_link( $tax ) ) . '" alt="' . esc_attr( sprintf( __( 'View all %s entries', 'astro-shortcodes' ), $tax->name ) ) . '">';
                do_action( 'astro_before_tax_title', $tax->term_id );  
                echo $tax->name;
                do_action( 'astro_after_tax_title', $tax->term_id );  
                echo '</a></li>';
            }
            echo '</ul>';
        } elseif ( $args['class'] == 'filters' ) { 
            echo '<ul class="astro-shortcodes taxonomy-filter ' . $args['tax'] . '">';
            echo '<li class="all">' . __( 'All', 'astro-shortcodes' ) . '</li>';
            foreach ( $taxs as $tax ) {
                echo '<li class="' . $tax->slug . '">';
                do_action( 'astro_before_tax_title', $tax->term_id );  
                echo $tax->name;
                do_action( 'astro_after_tax_title', $tax->term_id );  
                echo '</li>';
            }
            echo '</ul>';
        } elseif ( $args['class'] == 'masonry' ) {
            echo '<div class="astro-shortcodes taxonomy-list masonry section group">';
            $i = 1;
            $columns = '';
            foreach ( $taxs as $tax ) {
                $type_img = get_term_meta( $tax->term_id, 'tax_image', true);
                $banner_img = wp_get_attachment_url( $type_img );
                if ( $i <= 4 || $i == 6 ) { $columns = 'span_4_of_12'; }
                if ( $i == 5 ) { $columns = 'span_8_of_12'; }
                echo '<div class="col ' . $columns . '">';
                if ( $banner_img ) {
                    echo '<a href="' . esc_url( get_term_link( $tax ) ) . '"  alt="' . $tax->name . '">';
                    echo '<img src="' . $banner_img . '"/>'; 
                    echo '</a>';
                }
                echo '<h3><a href="' . esc_url( get_term_link( $tax ) ) . '"  alt="' . $tax->name . '">';
                do_action( 'astro_before_tax_title', $tax->term_id );  
                echo $tax->name;
                do_action( 'astro_after_tax_title', $tax->term_id );  
                echo '</a></h3>';   
                echo '</div>';
                $i++;
            }
            echo  '</div>';
        } else {
            echo '<div class="astro-shortcodes taxonomy-list mosaic section group">';
            foreach ( $taxs as $tax ) {
                $type_img = get_term_meta( $tax->term_id, 'tax_image', true);
                $banner_img = wp_get_attachment_url( $type_img );
                echo '<div class="col span_6_of_12">';
                if ( $banner_img ) {
                    echo '<a href="' . esc_url( get_term_link( $tax ) ) . '"  alt="' . $tax->name . '">';
                    echo '<img src="' . $banner_img . '"/>'; 
                    echo '</a>';
                }
                echo '<h3><a href="' . esc_url( get_term_link( $tax ) ) . '"  alt="' . $tax->name . '">';
                do_action( 'astro_before_tax_title', $tax->term_id );  
                echo $tax->name;
                do_action( 'astro_after_tax_title', $tax->term_id );                  
                echo '</a></h3>';   
                echo '</div>';
            }
            echo '</div>';
        }
    } 

    $module = ob_get_contents();
    ob_end_clean();
    wp_reset_postdata();
    return $module;
}

add_shortcode('filter', 'astro_shortcodes_tax_filter');
function astro_shortcodes_tax_filter($atts) {

    $args = shortcode_atts(array(
        'type' => 'post'
        ,'tax' => 'category'
    ), $atts, 'filter' );

    $terms = get_terms( $args['tax'], array(
        'orderby'    => 'count',
        'hide_empty' => 1,
    ) ); 

    $output = '';
    $output .= '<div class="astro-shortcodes taxonomy-filter ' . $args['tax'] . '"><ul><li class="all active">' . __( 'All', 'astro-shortcodes' ) . '</li>';

    foreach ( $terms as $term ) {
        $query_args = array(
            'post_type' => $args['type'],
            'tax_query' => array(
                array(
                    'taxonomy' => $args['tax'],
                    'field'    => 'slug',
                    'terms'    => array ( $term->slug )
                )
            ),
        );
        $filter_loop = new WP_Query($query_args);

        if( $filter_loop->have_posts() ): 
            $output .= '<li class="' . esc_attr( $term->slug ) . '">' . esc_html( $term->name ) . '</li>';
        wp_reset_postdata();
        endif;
    }

    $output .= '</ul></div><!-- .taxonomy-filter -->';

    echo $output;
}