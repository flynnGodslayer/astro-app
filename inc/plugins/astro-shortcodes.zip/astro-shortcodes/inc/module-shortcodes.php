<?php
/**
 * Module Shortcodes
 *
 * @package Astro Shortcodes
 */

/**
 * "CALLOUT-BUTTON" Shortcode
 */
add_shortcode('callout-button', 'astro_shortcodes_callout_button');
function astro_shortcodes_callout_button( $atts ) {
    $args = shortcode_atts(array(
        'link' => ''
        ,'text' => ''
        ,'class' => ''
    ), $atts, 'callout-button' );
    
    ob_start();
    ?>
    <a class="astro-shortcodes callout-button<?php if (isset($args['class'])) { echo ' ' . esc_attr($args['class']);} ?>" href="<?php echo esc_url( $args['link'] ); ?>"><?php echo esc_html( $args['text'] ); ?></a>
    <?php 
    $button = ob_get_contents();
    ob_end_clean();
    return $button;
}


/**
 * "ASTRO-POPUP" Shortcode
 */
add_shortcode('astro-popup', 'astro_shortcodes_popup');
function astro_shortcodes_popup( $atts, $content = '' ) {
    $args = shortcode_atts( array(
        'name'     => 'astro-popup'
        ,'color'    => '#ffffff'
    ), $atts, 'astro-popup' );

    $name = esc_attr( $args['name'] );

    ob_start();
    ?>

    <div id="<?php echo $name; ?>" class="astro-popup">
        <div class="background" for-popup="<?php echo $name; ?>"></div>
        <div class="message" style="background-color: <?php echo esc_attr( $args['color'] ); ?>;">
            <button class="close" for-popup="<?php echo $name; ?>"></button>
            <?php echo do_shortcode( $content ); ?>
        </div>
    </div>    
    
    <?php 
    $popup = ob_get_contents();
    ob_end_clean();

    return $popup;
}

/**
 * "ASTRO-SHARING" Shortcode
 */
add_shortcode( 'astro-sharing', 'astro_shortcodes_sharing' );
function astro_shortcodes_sharing() {
    if ( function_exists( 'sharing_display' ) ) {
        sharing_display( '', true );
    }
    if ( class_exists( 'Jetpack_Likes' ) ) {
        $custom_likes = new Jetpack_Likes;
            echo $custom_likes->post_likes( '' );
    }
}

/**
 * "ASTRO-MAP" Shortcode
 */
add_shortcode('astro-map', 'astro_shortcodes_map');
function astro_shortcodes_map( $atts ) {
    $args = shortcode_atts( array(
        'id'        => 'astro-map',
        'title'     => __( 'Our Location', 'astro-shortcodes' ),
        'class'     => '',
        'width'     =>  '2560',
        'height'    =>  '300',
        'key'       => 'AIzaSyD4VU_kLnb-i3NsHMa-VnNw5SWFMaI4b7s',
        'lat'       => '',
        'long'      => '',
        'zoom'      => '15'
    ), $atts, 'astro-map' );

    $id = $args['id'];
    $title = $args['title'];
    $class = $args['class'];
    $width = $args['width'];
    $height = $args['height'];
    $key = $args['key'];
    $lat = $args['lat'];
    $long = $args['long'];
    $zoom = $args['zoom'];

    ob_start();
    
    if ( $class != 'pin' ) : 
    ?>
    <div id="<?php echo esc_attr($id); ?>">
        <iframe width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/view?key=<?php echo esc_attr($key); ?>&center=<?php echo esc_attr($lat) . ',' . esc_attr($long); ?>&zoom=<?php echo esc_attr($zoom); ?>" allowfullscreen></iframe>
    </div>
    <?php else : ?>
    <div id="<?php echo esc_attr($id); ?>" class="astro-map"></div>
        <?php if ( $lat && $long ) : ?>
        <script type="text/javascript">

            var map, latlng, mapOptions, marker;
            function initMap() {
                latlng = new google.maps.LatLng(<?php echo esc_attr( $lat ) . ',' . esc_attr( $long ); ?>);
                mapOptions = {
                    zoom: <?php echo absint( $zoom ); ?>,
                    center: latlng,
                    scrollwheel: false
                }

                map = new google.maps.Map(document.getElementById(<?php echo "'" . esc_attr($id) . "'"; ?>), mapOptions);

                marker = new google.maps.Marker({
                    position: latlng,
                    title: <?php echo '"' . esc_attr( $title ) .'"'; ?>
                });

                marker.setMap(map);
            }

        </script>
    <?php 
        endif;
    endif; 
    $map = ob_get_contents();
    ob_end_clean();

    return $map;
}

/**
 * "TAB-BUTTON" Shortcode
 */
add_shortcode('tab-button', 'astro_shortcodes_tab_button');
function astro_shortcodes_tab_button( $atts ) {
    $args = shortcode_atts(array(
        'id'       => '',
        'title'    => ''
    ), $atts, 'tab-button' );
    
    if ( $args['id'] == '' && $args['title'] == '' ) {
        return;
    }

    ob_start();
    ?>
    <button type="button" name="<?php echo esc_attr( $args['id'] ); ?>" class="astro-shortcodes tab-button"><?php echo esc_html( $args['title'] ); ?></button>
    <?php 
    $button = ob_get_contents();
    ob_end_clean();
    return $button;
}

/**
 * "TAB-CONTENT" Shortcode
 */
add_shortcode('tab-content', 'astro_shortcodes_tab_content');
function astro_shortcodes_tab_content( $atts, $content = '' ) {
    $args = shortcode_atts( array(
        'id'     => ''
    ), $atts, 'tab-content' );

    if ( $args['id'] == '' ) {
        return;
    }

    ob_start();
    ?>

    <div id="<?php echo esc_attr( $args['id'] ); ?>" class="astro-shortcodes tab-content">
        <?php echo do_shortcode( $content ); ?>
    </div>    
    
    <?php 
    $tab = ob_get_contents();
    ob_end_clean();

    return $tab;
}
