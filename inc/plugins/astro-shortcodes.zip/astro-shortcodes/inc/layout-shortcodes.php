<?php
/**
 * Layout Shortcodes
 *
 * @package Astro Shortcodes
 */

/**
 * "SECTION" Shortcode
 */
add_shortcode('section', 'astro_shortcodes_section');
function astro_shortcodes_section( $atts, $content = '' ) {
	
	// Deafult Attributes
	$args = shortcode_atts(array(
        'id'        => ''
        ,'class'    => ''
        ,'image'    => ''
        ,'color'    => ''
    ), $atts, 'section' );

	// Check for id name
    if ( $args['id'] ) {
    	$id = ' id="' . esc_attr( $args['id'] ) . '"';
    } else {
    	$id = '';
    }

	// Check and construct class
	$class = 'astro-shortcodes';
    if ( $args['class'] ) { 
        $class .=  ' ' . esc_attr( $args['class'] );
    }

    // Check for image background
    if ( $args['image'] && ( strpos( $class, 'half' ) == false || strpos( $class, 'transparent' ) !== false ) )  {
        $bg_image = 'background-image: url(' . esc_url( $args['image'] ) . ');';
    } else {
        $bg_image = '';
    }

    if ( $args['color'] ) {
        $bg_color = 'background-color: ' . esc_attr( $args['color'] ) . ';';
    } elseif ( strpos( $class, 'transparent' ) !== false ) {
        $bg_color = 'background-color: #ffffff;';
    } else {
        $bg_color = '';
    }
    if ( $bg_image || $bg_color ) {
    	$style = ' style="' . $bg_image . $bg_color . '"';
    } else {
    	$style = '';
    }
	
	ob_start();
    ?><section<?php echo  $id; ?> class="<?php echo $class; ?>"<?php echo $style; ?>><?php 
        if ( strpos( $class, 'transparent' ) !== false ) :
    ?><div class="overlay" style="<?php echo $bg_color; ?>"></div>
    <?php
        endif;
        if ( strpos( $class, 'half' ) !== false ) :
    ?><div class="content-half"><div class="padder"><?php echo do_shortcode( $content ); ?></div></div><?php
            if ( strpos( $class, 'transparent' ) == false ) : 
    ?><div class="image-half" style="background-image: url(<?php echo esc_url( $args['image'] ); ?>);"></div><?php
            endif;
        else :
            echo do_shortcode( $content ); 
        endif;
    ?></section>
    <?php 
    $section = ob_get_contents();
    ob_end_clean();
    return $section;
}


/**
 * "COLUMN" Shortcode
 */
add_shortcode('column', 'astro_shortcodes_column');
function astro_shortcodes_column( $atts, $content = '' ) {
	$args = shortcode_atts(array(
        'width'     => '1'
        ,'offset'   => ''
        ,'class'    => ''
    ), $atts, 'column' );

    if ( $args['offset'] ) {
    	$offset = 'offset_' . $args['offset'];
    } else {
    	$offset = '';
    }

    if ( $args['class'] ) {
        $extra_class = ' ' . $args['class'];
    } else {
        $extra_class = '';
    }

    $class = 'col ' . $offset . ' span_' . $args['width'] . '_of_12' . $extra_class;
	
	ob_start();

    ?><div class="<?php echo esc_attr( $class ); ?>"><?php echo do_shortcode( $content ); ?></div><?php 
    
    $column = ob_get_contents();
    ob_end_clean();
    return $column;
}

/**
 * "COLUMN-CLEAR" Shortcode
 */
add_shortcode( 'column-clear', 'astro_shortcodes_column_clear' );
function astro_shortcodes_column_clear() {
    ob_start();

    ?><hr class="astro-shortcodes column-clear"><?php 
    
    $column_clear = ob_get_contents();
    ob_end_clean();
    return $column_clear;
}

/**
 * "SUB-COLUMN" Shortcode
 */
add_shortcode('sub-column', 'astro_shortcodes_sub_column');
function astro_shortcodes_sub_column( $atts, $content = '' ) {
    $args = shortcode_atts(array(
        'width'     => '1'
        ,'offset'   => ''
        ,'class'    => ''
    ), $atts, 'sub-column' );

    if ( $args['offset'] ) {
        $offset = 'offset_' . $args['offset'];
    } else {
        $offset = '';
    }

    if ( $args['class'] ) {
        $extra_class = ' ' . $args['class'];
    } else {
        $extra_class = '';
    }

    $class = 'col ' . $offset . ' span_' . $args['width'] . '_of_12' . $extra_class;
    
    ob_start();
    ?>

    <div class="<?php echo esc_attr( $class ); ?>"><?php echo do_shortcode( $content ); ?></div>
    
    <?php 
    $column = ob_get_contents();
    ob_end_clean();
    return $column;
}

/**
 * "BULLET" Shortcode
 */
add_shortcode('bullet', 'astro_shortcodes_bullet');
function astro_shortcodes_bullet( $atts, $content = '' ) {
    $args = shortcode_atts(array(
        'class'    => 'left'
    ), $atts, 'bullet' );
    
    ob_start();
    ?>
    <aside class="astro-shortcodes bullet <?php echo esc_attr( $args[ 'class' ] ); ?>"><?php echo do_shortcode( $content ); ?></aside>
    <?php 
    $bullet = ob_get_contents();
    ob_end_clean();
    return $bullet;
}

/**
 * "ASTRO-ICON" Shortcode
 */
add_shortcode('astro-icon', 'astro_shortcodes_icon');
function astro_shortcodes_icon( $atts ) {
    $test = $atts;
    $args = shortcode_atts(array(
        'name'    => '',
        'class'   => 'font-awesome',
        'link'    => '',
    ), $atts, 'astro-icon' );

    if ( $args[ 'name' ] ) {
        $name = $args[ 'name' ];
    } elseif ( $atts[0] ) {
        $name = $atts[0];
    }

    $link = $args[ 'link' ];
    
    ob_start();
    if ( $link != '' ) :
    ?><a class="icon-link" href="<?php echo esc_url( $link ); ?>"><?php 
    endif;
    if ( $args['class'] == 'font-awesome' ) :
    ?><i class="fa fa-<?php echo esc_attr( $name ); ?>"></i><?php
    else :
    ?><svg class="icon icon-<?php echo esc_attr( $name ); ?>"><use xlink:href="#icon-<?php echo esc_attr( $name ); ?>"></use></svg><?php         
    endif;
    if ( $link != '' ) :
    ?></a><?php
    endif;
    $icon = ob_get_contents();
    ob_end_clean();
    return $icon;
}