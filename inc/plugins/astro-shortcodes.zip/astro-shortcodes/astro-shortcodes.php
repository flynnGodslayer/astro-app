<?php
/**
 * Plugin Name:   Astro Shortcodes
 * Plugin URI:    https://astroweb.me
 * Description:   Adds several shortcodes for Astro Web themes.
 * Version:       2.6
 * Author:        Astro Web
 * Author URI:    http://astroweb.me
 * Text Domain:   astro-shortcodes
 * Domain Path:   /languages
 *
 */
if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}

function astro_shortcodes_init() {
	$plugin_dir = basename( dirname(__FILE__) ) . '/languages/';
	load_plugin_textdomain( 'astro-shortcodes', false, $plugin_dir );
}
add_action('plugins_loaded', 'astro_shortcodes_init');

/**
 * Enqueue plugin scripst and styles
 */
function astro_shortcodes_enqueue_styles() {

	// PLUGIN STYLES
	wp_enqueue_style( 'astro_shortcodes_css', plugins_url( 'css/style.css', __FILE__ ), array(), null, false );

	// PLUGIN SCRIPTS
  	wp_enqueue_script( 'astro-shortcodes-scripts', plugins_url( '/js/astro-shortcodes-min.js', __FILE__ ), array( 'jquery' ), false, true );

  	// FONT AWESOME
  	wp_enqueue_script( 'astro-shortcodes-font-awesome', 'https://use.fontawesome.com/b06e6e12f6.js', array(), false, false );
}
add_action( 'wp_enqueue_scripts', 'astro_shortcodes_enqueue_styles' );


/**
 * Remove wpautop from shortcodes.
 */
function astro_shortcodes_autop() {
	remove_filter( 'the_content', 'wpautop' );
	add_filter( 'the_content', 'wpautop' , 99);	
	add_filter( 'the_content', 'shortcode_unautop', 100 );
}
add_action( 'template_redirect', 'astro_shortcodes_autop' );


/**
 * Allow Skype protocol.
 */
add_filter( 'kses_allowed_protocols' , 'astro_shortcodes_skype_link_enabler' );
function astro_shortcodes_skype_link_enabler( $protocols ){
	$protocols[] = 'skype';
	return $protocols;
}


/**
 * Layout Shortcodes
 */
require_once dirname( __FILE__ ) . '/inc/layout-shortcodes.php';

/**
 * Module Shortcodes
 */
require_once dirname( __FILE__ ) . '/inc/module-shortcodes.php';

/**
 * Posts Shortcodes
 */
require_once dirname( __FILE__ ) . '/inc/posts-shortcodes.php';

/**
 * Taxonomy Shortcodes
 */
require_once dirname( __FILE__ ) . '/inc/taxonomy-shortcodes.php';

