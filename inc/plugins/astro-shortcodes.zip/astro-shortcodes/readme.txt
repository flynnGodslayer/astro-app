=== Astro Shortcodes ===
Contributors: Astro Web
Tags: 
Requires at least: 4.5
Tested up to: 4.7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds several shortcodes for Astro Web themes.

== Description ==



= Docs & Support =


== Installation ==


== Changelog ==

For more information, see [Releases](http://).

= 2.7. = 
* Added "tab-button" and "tab-content" shortcodes for tabbed layouts.
* Fixed parallax background for mobile devices.
* Removed Google Analytics functionality, to avoid conflict with SEO plugins.

= 2.6 =
* Added Font Awesome CDN and implemented it for the "astro-icon" shortcode.
* Added option to include excerpt in "recent-items" shortcode.
* Added link attribute to the "astro-icon" shortcode.
* Replaced "category-button" shortcode with "taxonomy-button".
* Corrected styles, setting padding in pixels.
* Added a new style to sections called "half".
* Added a "column-clear" shortcode.
* Added a "page-button" shortcode.

= 2.5 =

* Modified the "taxonomy-list" shortcode to include filter functionality for posts.
* Modified the "bullet" shortcode to utilize de "aside" HTML tag.
* Added "zoom" attribute to the "astro-map" shortcode.
* Added Customizer option for Google Analytics code.

= 2.4 =

* Added "Read Me" file (readme.txt).
* Added "astro-icon" shortcode for the use of SVG icons in the text editor.
* Minor fix to "bullet" shortcode.
* Correctly positioned backgrounds for the "section" shortcode (it was previously only positioned for parallax sections).
* Added "astro-map" shortcode for embedding Google Maps.

= 2.3 =

* Improvements and additions.

= 2.0 =

* Improvements and additions.

= 1.0 =

* Initial build.
